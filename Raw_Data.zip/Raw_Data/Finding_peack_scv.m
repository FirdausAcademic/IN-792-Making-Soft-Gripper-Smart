%% About Me%%
%This
clc; 
clear; 
close all;
%%
% % Read data from a CSV file
fileNumber=10;
filename = sprintf('sensor_data_spongeBall%d_torq_1.csv',fileNumber); % Specify the filename
%data = csvread(filename);
data = readmatrix(filename);
shoft=0;
hard=1;
%%
% Find local maxima
localMaximaIndices1 = find(islocalmax(data(:,1)));
localMaximaIndices2 =find(islocalmax(data(:,2)));
localMaximaIndices3 =find(islocalmax(data(:,3)));
% Extract local maxima values
localMaximaValues1 = data(localMaximaIndices1,1);
localMaximaValues2 = data(localMaximaIndices2,2);
localMaximaValues3 = data(localMaximaIndices3,3);

%%
% Display results
% disp('Indices of local maxima:');
% disp(localMaximaIndices);
% disp('Values of local maxima:');
% disp(localMaximaValues);

% Plot the data and local maxima
figure;
subplot(3,1,1)
plot(data(:,1), '-r'); % Plot the original data in blue
hold on;
plot(localMaximaIndices1, localMaximaValues1, 'or'); % Plot local maxima in red
hold off;
title('Local Maxima in Data');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');
subplot(3,1,2)
plot(data(:,2), '-g'); % Plot the original data in blue
hold on;
plot(localMaximaIndices2, localMaximaValues2, 'og'); % Plot local maxima in red
hold off;
title('Local Maxima in Data');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');
subplot(3,1,3)
plot(data(:,3), '-b'); % Plot the original data in blue
hold on;
plot(localMaximaIndices3, localMaximaValues3, 'ob'); % Plot local maxima in red
hold off;
title('Local Maxima in Data');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');
%%
% Define the threshold value
threshold1 =213; % Specify the threshold value
threshold2 = 350; % Specify the threshold value
threshold3 = 720; % Specify the threshold value
% Filter out local maxima below the threshold
thresholdedIndices1 = localMaximaIndices1(localMaximaValues1 > threshold1);
thresholdedIndices2 = localMaximaIndices2(localMaximaValues2 > threshold2);
thresholdedIndices3 = localMaximaIndices3(localMaximaValues3 > threshold3);

% Define the minimum distance threshold
indicesDist1 = 300; % Specify the minimum distance between points
indicesDist2 = 300; % Specify the minimum distance between points
indicesDist3 = 1050; % Specify the minimum distance between points

% Initialize a logical array to keep track of points to retain
keepPoints1 = true(length(thresholdedIndices1), 1);

for i = 2:length(thresholdedIndices1)
    if thresholdedIndices1(i) - thresholdedIndices1(i-1) < indicesDist1 
        keepPoints1(i) = false;
    end
end
% Initialize a logical array to keep track of points to retain
keepPoints2 = true(length(thresholdedIndices2), 1);

for i = 2:length(thresholdedIndices2)
    if thresholdedIndices2(i) - thresholdedIndices2(i-1) < indicesDist2 
        keepPoints2(i) = false;
    end
end

% Initialize a logical array to keep track of points to retain
keepPoints3 = true(length(thresholdedIndices3), 1);

for i = 2:length(thresholdedIndices3)
    if thresholdedIndices3(i) - thresholdedIndices3(i-1) < indicesDist3 
        keepPoints3(i) = false;
    end
end


% Filter the data to keep only the points that meet the criteria
filteredthresholdedIndices1 = thresholdedIndices1(keepPoints1);
filteredthresholdedIndices2 = thresholdedIndices2(keepPoints2);
filteredthresholdedIndices3 = thresholdedIndices3(keepPoints3);
% Extract local maxima values
localMaximaValues1 = data(filteredthresholdedIndices1,1);
localMaximaValues2 = data(filteredthresholdedIndices2,2);
localMaximaValues3 = data(filteredthresholdedIndices3,3);
%thresholdedValues = localMaximaValues(localMaximaValues > threshold);
thresholdedValues1 = localMaximaValues1(localMaximaValues1 > threshold1);
thresholdedValues2 = localMaximaValues2(localMaximaValues2 > threshold2);
thresholdedValues3 = localMaximaValues3(localMaximaValues3 > threshold3);

%%
% Display results
% disp('Indices of local maxima greater than the threshold:');
% disp(filteredthresholdedIndices1);
% disp('Values of local maxima greater than the threshold:');
% disp(thresholdedValues1);

% Plot the data and local maxima
figure;
subplot(3,1,1)
plot(data(:,1), '-b'); % Plot the original data in blue
hold on;
plot(filteredthresholdedIndices1, thresholdedValues1, 'or'); % Plot local maxima in red
hold off;
title('Local Maxima in Data');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');
subplot(3,1,2)
plot(data(:,2), '-b'); % Plot the original data in blue
hold on;
plot(filteredthresholdedIndices2, thresholdedValues2, 'or'); % Plot local maxima in red
hold off;
title('Local Maxima in Data');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');
subplot(3,1,3)
plot(data(:,3), '-b'); % Plot the original data in blue
hold on;
plot(filteredthresholdedIndices3, thresholdedValues3, 'or'); % Plot local maxima in red
hold off;
title('Local Maxima in Data');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');
%% 
dataClass=[];
band1=500;
band2=500;
band3=500;
for i=1:10
dataClass=[dataClass;data(filteredthresholdedIndices1(i)-band1*0.2:filteredthresholdedIndices1(i)+band1*0.8,1)' ...
           data(filteredthresholdedIndices2(i)-band2*0.2:filteredthresholdedIndices2(i)+band2*0.8,2)' ...
           data(filteredthresholdedIndices3(i)-band3*0.2:filteredthresholdedIndices3(i)+band3*0.8,3)'];
end
%%
% dataClass=dataClass';
figure(3)
plot(dataClass(1,:))
%% Including Class
datawithClass=[dataClass ones(10,1)*shoft];
sfilename=sprintf('sensor_data_spongeBall%d_with_class.csv',fileNumber);
%csvwrite(sfilename,datawithClass)
writematrix(datawithClass, sfilename);
% pause(0.1)
% end
