% This code reads data from a CSV file and finds local maxima,
% then collects some required data points around those maxima.
% The CSV file contains data from three piezoelectric sensors.
% For the same index maxima, the data points around those maxima
% for three sensors are stacked in a single column and plotted.

clc; 
clear; 
close all;

%% Initialization and Data Reading
fileNumber = 8;
filename = sprintf('sensor_data_clothbundle%d_torq_1.csv', fileNumber); % Specify the filename
data = readmatrix(filename); % Read data from the CSV file

shoft = 0;
hard = 1;

%% Local Maxima Identification
% Find local maxima in each column of the data
localMaximaIndices1 = find(islocalmax(data(:,1)));
localMaximaIndices2 = find(islocalmax(data(:,2)));
localMaximaIndices3 = find(islocalmax(data(:,3)));

% Extract local maxima values
localMaximaValues1 = data(localMaximaIndices1, 1);
localMaximaValues2 = data(localMaximaIndices2, 2);
localMaximaValues3 = data(localMaximaIndices3, 3);

%% Plotting Local Maxima
figure;
subplot(3,1,1)
plot(data(:,1), '-r'); % Plot the original data in red
hold on;
plot(localMaximaIndices1, localMaximaValues1, 'or'); % Plot local maxima in red
hold off;
title('Local Maxima in Data - Sensor 1');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');

subplot(3,1,2)
plot(data(:,2), '-g'); % Plot the original data in green
hold on;
plot(localMaximaIndices2, localMaximaValues2, 'og'); % Plot local maxima in green
hold off;
title('Local Maxima in Data - Sensor 2');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');

subplot(3,1,3)
plot(data(:,3), '-b'); % Plot the original data in blue
hold on;
plot(localMaximaIndices3, localMaximaValues3, 'ob'); % Plot local maxima in blue
hold off;
title('Local Maxima in Data - Sensor 3');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');

%% Thresholding Local Maxima
% Define the threshold values for each column
threshold1 = 213;
threshold2 = 350;
threshold3 = 720;

% Filter out local maxima below the threshold
thresholdedIndices1 = localMaximaIndices1(localMaximaValues1 > threshold1);
thresholdedIndices2 = localMaximaIndices2(localMaximaValues2 > threshold2);
thresholdedIndices3 = localMaximaIndices3(localMaximaValues3 > threshold3);

% Define the minimum distance threshold between points
indicesDist1 = 300;
indicesDist2 = 300;
indicesDist3 = 1050;

% Initialize logical arrays to keep track of points to retain
keepPoints1 = true(length(thresholdedIndices1), 1);
keepPoints2 = true(length(thresholdedIndices2), 1);
keepPoints3 = true(length(thresholdedIndices3), 1);

% Retain points based on the minimum distance threshold
for i = 2:length(thresholdedIndices1)
    if thresholdedIndices1(i) - thresholdedIndices1(i-1) < indicesDist1 
        keepPoints1(i) = false;
    end
end

for i = 2:length(thresholdedIndices2)
    if thresholdedIndices2(i) - thresholdedIndices2(i-1) < indicesDist2 
        keepPoints2(i) = false;
    end
end

for i = 2:length(thresholdedIndices3)
    if thresholdedIndices3(i) - thresholdedIndices3(i-1) < indicesDist3 
        keepPoints3(i) = false;
    end
end

% Filter the data to keep only the points that meet the criteria
filteredthresholdedIndices1 = thresholdedIndices1(keepPoints1);
filteredthresholdedIndices2 = thresholdedIndices2(keepPoints2);
filteredthresholdedIndices3 = thresholdedIndices3(keepPoints3);

% Extract local maxima values after filtering
localMaximaValues1 = data(filteredthresholdedIndices1, 1);
localMaximaValues2 = data(filteredthresholdedIndices2, 2);
localMaximaValues3 = data(filteredthresholdedIndices3, 3);

% Thresholded values
thresholdedValues1 = localMaximaValues1(localMaximaValues1 > threshold1);
thresholdedValues2 = localMaximaValues2(localMaximaValues2 > threshold2);
thresholdedValues3 = localMaximaValues3(localMaximaValues3 > threshold3);

%% Plotting Filtered Local Maxima
figure;
subplot(3,1,1)
plot(data(:,1), '-b'); % Plot the original data in blue
hold on;
plot(filteredthresholdedIndices1, thresholdedValues1, 'or'); % Plot local maxima in red
hold off;
title('Filtered Local Maxima in Data - Sensor 1');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');

subplot(3,1,2)
plot(data(:,2), '-b'); % Plot the original data in blue
hold on;
plot(filteredthresholdedIndices2, thresholdedValues2, 'or'); % Plot local maxima in red
hold off;
title('Filtered Local Maxima in Data - Sensor 2');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');

subplot(3,1,3)
plot(data(:,3), '-b'); % Plot the original data in blue
hold on;
plot(filteredthresholdedIndices3, thresholdedValues3, 'or'); % Plot local maxima in red
hold off;
title('Filtered Local Maxima in Data - Sensor 3');
xlabel('Index');
ylabel('Value');
legend('Data', 'Local Maxima');

%% Collecting Data Points Around Maxima
dataClass = [];
band1 = 500;
band2 = 500;
band3 = 500;

for i = 1:10
    dataClass = [dataClass; data(filteredthresholdedIndices1(i)-band1*0.2:filteredthresholdedIndices1(i)+band1*0.8, 1)' ...
                          data(filteredthresholdedIndices2(i)-band2*0.2:filteredthresholdedIndices2(i)+band2*0.8, 2)' ...
                          data(filteredthresholdedIndices3(i)-band3*0.2:filteredthresholdedIndices3(i)+band3*0.8, 3)'];
end

%% Plotting Collected Data Points
figure(3)
plot(dataClass(1,:))
xlabel('Index');
ylabel('Value');
title('Combination of three sensors for training');
%% Including Class and Saving to CSV
% datawithClass = [dataClass ones(10,1) * shoft];
% sfilename = sprintf('sensor_data_spongeBall%d_with_class.csv', fileNumber);
% writematrix(datawithClass, sfilename);
