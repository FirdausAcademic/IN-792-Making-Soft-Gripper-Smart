% List of CSV files to be combined
fileList = {'f1.csv', 'f2.csv', 'f3.csv', 'f4.csv', 'f5.csv', 'f6.csv', 'f7.csv', 'f8.csv', 'f9.csv', 'f10.csv', ...
            'f11.csv', 'f12.csv', 'f13.csv', 'f14.csv', 'f15.csv', 'f16.csv', 'f17.csv', 'f18.csv', 'f19.csv', ...
            'f20.csv', 'f21.csv', 'f22.csv', 'f23.csv', 'f24.csv', 'f25.csv', 'f26.csv', 'f27.csv', 'f28.csv', ...
            'f29.csv', 'f30.csv', 'f31.csv', 'f32.csv', 'f33.csv', 'f34.csv', 'f35.csv', 'f36.csv', 'f37.csv', ...
            'f38.csv', 'f39.csv', 'f40.csv', 'f41.csv', 'f42.csv', 'f43.csv', 'f44.csv', 'f45.csv', 'f46.csv', ...
            'f47.csv', 'f48.csv', 'f49.csv', 'f50.csv', 'f51.csv', 'f52.csv', 'f53.csv', 'f54.csv', 'f55.csv', ...
            'f56.csv', 'f57.csv', 'f58.csv', 'f59.csv', 'f60.csv', 'f61.csv', 'f62.csv', 'f63.csv', 'f64.csv', ...
            'f65.csv', 'f66.csv', 'f67.csv', 'f68.csv', 'f69.csv', 'f70.csv', 'f71.csv', 'f72.csv', 'f73.csv', ...
            'f74.csv', 'f75.csv', 'f76.csv', 'f77.csv', 'f78.csv', 'f79.csv'}; 

outputFile = 'combinedFile.csv';  % Name of the output file

% Initialize an empty table to store combined data
combinedData = [];

% Loop through each file and append its data to the combinedData table
for i = 1:length(fileList)
    % Read the current file
    currentData = readtable(fileList{i});
    
    % Append the data to the combinedData table
    combinedData = [combinedData; currentData];
end

% Write the combined data to the output file as a CSV file
writetable(combinedData, outputFile);

%disp(['Data combined into ', outputFile]);
